
import java.util.Hashtable;
public class Partie extends ChampGraphique{
  
  private int nb_tours;
  private List<Animal> animaux;
  private Hashtable grille_animaux;
  private int[][] grille;
  
  public Partie(int nb_tours, int taille_x, int taille_y, List<Animal> animaux)
  {
    super(taille_x,taille_y);
    this.nb_tours = nb_tours;
    grille = new int[taille_x][taille_y];
    grille_animaux = new Hashtable();
    this.remplir_grille();
    this.animaux = animaux;
  }

  private void remplir_grille()
  {
    for (int i=0; i<this.getHauteur(); i++)
      for (int j=0; j<this.getLargeur(); j++)
        // A modifier pour ne pas remplir tout le tableau (parametre int)
        this.grille[i][j]=1;
  }

  private void remplir_grille_animaux(){
    for (Animal a: this.animaux){
      grille_animaux.add(a.pos_x+","+a.pos_y,a); 
    }
  }

  public simuler(){
    Animal proie;
    while (this.animaux.size() > 0){
      for(Animal a : this.animaux){
        // Executer actions  
        /*On essaye de detecter une proie dans les cases à cotés*/ 
        proie = detecter(a);
        /*Si on a bien detecter une proie*/
        if (proie != null){
          if(!(a.manger(proie))){

          }
          else{
            // On pop proie de la liste et on met a jour la grille[i][j]
            maj(proie.pos_x,proie.pos_y,proie);
          }

        }

        p.colorierCase(a.getColor(),a.getPosX(),a.getPosY());
      }   
    }
  }

  private void maj(int x, int y, Animal a){
    
  }

  public int getCase(int x, int y)
  {
    return this.grille[x][y];
  }

  public void setCase(int x, int y)
  {
    this.grille[x][y]=2;
  }

  public int getTours()
  {
    return this.nb_tours;
  }

  public Animal detecter(Animal a){
    int a = x-1 < 0 ? x : x-1;
    int b = y-1 < 0 ? y : y-1;
    int c = x+2 > largeur ? x+1 : x+2;
    int d = y+2 > hauteur ? y+1 : y+2;

    Random r = new Random();
    int hasard = 0;

    for (int i = a ; i < c ; i++){
      for (int j=b ; j < d ; j++){
        if ( this.grille[i][j] == 2  ){ // and is proie of a 
          hasard = r.nextInt(100);
          if (hasard <= a.p_detection_proie*100){
            return grille_animaux[i+','+j];
          }
        }
      }
    }
    return null;
  }

}